package com.group.project.natalife.dao;

import java.util.List;

import com.group.project.natalife.model.Product;
import com.group.project.natalife.model.User;

public interface UserDao {

	/**
	 * Find a user by full name
	 * 
	 * @param name
	 * @return
	 */
	User findByName(String name);

	/**
	 * Find a user by email
	 * 
	 * @param email
	 * @return
	 */
	User findByEmail(String email);

	/**
	 * Find an ordered product of a user
	 * 
	 * @param email
	 * @param productId
	 * @return int
	 */
	int orderedProductByProductId(String email, int productId);

	/**
	 * Find a list of products that a user has ordered by email
	 * 
	 * @param email
	 * @return
	 */
	List<Product> findOrderedProducts(String email);

	/**
	 * 
	 * @param email
	 * @return orderId of user
	 */
	String getUserOrderId(String email);

	/**
	 * 
	 * @param email
	 * @param orderId
	 */
	void createUserOrderId(String email, String orderId);
}
