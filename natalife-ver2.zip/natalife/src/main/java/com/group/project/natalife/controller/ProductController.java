package com.group.project.natalife.controller;

import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.group.project.natalife.dao.ProductDao;
import com.group.project.natalife.dao.UserDao;
import com.group.project.natalife.model.Product;
import com.group.project.natalife.model.User;

@Controller
@SessionAttributes("user")
public class ProductController {

	@Autowired
	UserDao userDao;

	@Autowired
	ProductDao productDao;

	@ModelAttribute("product")
	public Product orderForm() {
		return new Product();
	}

	/**
	 * Method to show the initial HTML form
	 * 
	 * @return
	 */
	@GetMapping("/showProducts")
	public String showProducts(HttpSession session, Model model) {
		User user = (User) session.getAttribute("user");
		if (user != null) {
			List<Product> products = productDao.findAll();
			model.addAttribute("products", products);
			return "show-products";
		}
		return "login";
	}

	@PostMapping("/orderProduct")
	public String orderProduct(HttpSession session, @ModelAttribute("product") Product product, Model model) {
		User user = (User) session.getAttribute("user");

		String orderId = userDao.getUserOrderId(user.getEmail());
		String productId = product.getProductId();
		if (orderId == null) {
			orderId = UUID.randomUUID().toString();
			userDao.createUserOrderId(user.getEmail(), orderId);
		}

		productDao.addProductToOrder(orderId, productId, 1);
		return "redirect:userOrder";
	}
}
