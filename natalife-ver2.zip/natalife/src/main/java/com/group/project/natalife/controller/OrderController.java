package com.group.project.natalife.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.group.project.natalife.dao.ProductDao;
import com.group.project.natalife.dao.UserDao;
import com.group.project.natalife.model.Product;
import com.group.project.natalife.model.User;

@Controller
@SessionAttributes("user")
public class OrderController {

	@Autowired
	UserDao userDao;

	@Autowired
	ProductDao productDao;

	/**
	 * Method to show the initial HTML form
	 * 
	 * @return
	 */
	@GetMapping("/userOrder")
	public String showProducts(HttpSession session, Model model) {
		User user = (User) session.getAttribute("user");
		if (user != null) {
			List<Product> products = productDao.findAll();
			model.addAttribute("products", products);
			return "user-order";
		}
		return "redirect:show-products";
	}
}
