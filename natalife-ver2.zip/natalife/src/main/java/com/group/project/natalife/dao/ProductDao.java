package com.group.project.natalife.dao;

import java.util.List;

import com.group.project.natalife.model.Product;

public interface ProductDao {

	Product findById(String productId);

	List<Product> findAll();

	void addProductToOrder(String orderId, String productId, int quantity);
}
