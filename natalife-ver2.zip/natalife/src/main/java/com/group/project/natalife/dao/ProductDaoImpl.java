package com.group.project.natalife.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.group.project.natalife.model.Product;

@Repository
public class ProductDaoImpl implements ProductDao {

	NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Autowired
	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}

	@Override
	public Product findById(String productId) {

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("productId", productId);

		String sql = "SELECT * FROM products WHERE product_id=:productId";

		Product result = namedParameterJdbcTemplate.queryForObject(sql, params, new ProductMapper());

		// new BeanPropertyRowMapper(Customer.class));

		return result;

	}

	@Override
	public List<Product> findAll() {

		Map<String, Object> params = new HashMap<String, Object>();

		String sql = "SELECT * FROM products";

		List<Product> result = namedParameterJdbcTemplate.query(sql, params, new ProductMapper());

		return result;

	}

	@Override
	public void addProductToOrder(String orderId, String productId, int quantity) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("orderId", orderId);
		params.put("productId", productId);
		params.put("quantity", quantity);
		try {
			String sqlInsertOrder = "INSERT INTO order_product VALUES(:orderId, :productId, :quantity)";
			namedParameterJdbcTemplate.update(sqlInsertOrder, params);
		} catch (DuplicateKeyException ex) {
			String sqlUpdateOrder = "UPDATE order_product SET quantity= :quantity WHERE order_id = :orderId AND product_id = :productId";
			namedParameterJdbcTemplate.update(sqlUpdateOrder, params);
		}

	}

	private static final class ProductMapper implements RowMapper<Product> {

		public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
			Product product = new Product();
			product.setProductId(rs.getString("product_id"));
			product.setProductName(rs.getString("product_name"));
			product.setPrice(rs.getString("price"));
			product.setImage(rs.getString("image"));
			return product;
		}
	}

}
