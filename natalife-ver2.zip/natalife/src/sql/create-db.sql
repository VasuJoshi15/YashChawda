DROP TABLE user_order IF EXISTS;
DROP TABLE order_product IF EXISTS;
DROP TABLE orders IF EXISTS;
DROP TABLE users IF EXISTS;
DROP TABLE products IF EXISTS;

CREATE TABLE users (
  	email VARCHAR(50) PRIMARY KEY,
  	name VARCHAR(50),
  	password VARCHAR(20)
);

CREATE TABLE products (
  	product_id VARCHAR(100) PRIMARY KEY,
  	product_name VARCHAR(50) NOT NULL,
  	price VARCHAR(50) NOT NULL,
  	image VARCHAR(200) NOT NULL
);

CREATE TABLE orders (
	order_id VARCHAR(100) PRIMARY KEY,
	email VARCHAR(50),
	foreign key (email) references users(email)
);

CREATE TABLE user_order (
	email VARCHAR(50) PRIMARY KEY,
	order_id VARCHAR(100) ,
	foreign key (email) references users(email),
	foreign key (order_id) references orders(order_id)
);


CREATE TABLE order_product (
	order_id VARCHAR(100),
	product_id VARCHAR(100),
	quantity INTEGER,
	PRIMARY KEY(order_id, product_id),
	foreign key (order_id) references orders(order_id),
	foreign key (product_id) references products(product_id)
);
